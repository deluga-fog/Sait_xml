# 100_F clean detection dataset

Converted from Roboflow YOLO export.

Fixes:
- merged duplicate 8 classes into 4
- converted polygon/segmentation labels to detection bbox labels

Classes:
0 Terrorist
1 Counter-Terrorist
2 Terrorist Head
3 Counter-Terrorist Head

Stats:
- images: 100
- objects: 270
- empty labels: 28
- bad skipped lines: 0
- class counts: {1: 57, 3: 76, 2: 76, 0: 61}
